import React from "react";
function Greeting({ isLoggedIn }) {
  return (
    <div>
      <h1>{isLoggedIn ? "환영합니다" : "로그인하세요"}</h1>
    </div>
  );
}
// SubscribeButton.jsx
function SubscribeButton({ isSubscribed }) {
  return <button>{isSubscribed ? "구독중 ✓" : "구독하기"}</button>;
}
// StatusBadge.jsx
function StatusBadge({ isOnline }) {
  return (
    <span
      style={{
        color: isOnline ? "green" : "gray",
        fontWeight: "bold",
      }}
    >
      {isOnline ? "● 온라인" : "○ 오프라인"}
    </span>
  );
}
function NewMail({ newMailCount }) {
  return (
    <>
      <h3>메일함{newMailCount > 0 && "🆕"}</h3>
      {newMailCount > 0 && (
        <div>새로운 메시지가 {newMailCount}개 있습니다.</div>
      )}
    </>
  );
}
function OrderStatus({ status }) {
  return (
    <div>
      <h2>주문 현황</h2>
      {status === "pending" && <p>⏱️ 주문 접수 중...</p>}
      {status === "preparing" && <p>👨‍🍳 음식 준비 중...</p>}
      {status === "delivering" && <p>🚗 배달 중...</p>}
      {status === "completed" && <p>✅ 배달 완료!</p>}
    </div>
  );
}
function Weather({ temperature }) {
  let message;
  if (temperature >= 30) {
    message = "🥵 매우 더워요";
  } else if (temperature >= 20) {
    message = "😊 적당해요";
  } else if (temperature >= 10) {
    message = "🧥 쌀쌀해요";
  } else {
  }
  message = "🥶 매우 추워요";

  // TODO: 온도에 따른 메시지 지정하기 (if~else if~else)
  // 30도 이상: "🥵 매우 더워요"
  // 20-29도: "😊 적당해요"
  // 10-19도: "🧥 쌀쌀해요"
  // 10도 미만: "🥶 매우 추워요"

  return (
    <div>
      <h2>현재 온도: {temperature}°C</h2>
      <p>{message}</p>
    </div>
  );
}
function ProductCard({ product }) {
  const item = { name: "노트북", stock: 5, onSale: true };

  return (
    <div>
      <h3>{item.name}</h3>
      {item.stock === 0 ? "❌품절" : `${item.stock}개`}
      {item.stock <= 5 ? "⚠️품절임박" : product.stock}
      {(product.onSale = true ? "🔥할인중!" : 0)}
      {/* TODO: 
        1. stock이 0이면 "❌품절" 표시, 아니면 재고수량 표시
        2. stock이 5개 이하면 "⚠️품절임박" 표시
        3. onSale이 true면 "🔥할인중!" 배지
      */}
    </div>
  );
}
// 컴포넌트 정의
function Like({ isLiked }) {
  return (
    <div>
      <h3>좋아요 누르기</h3>
      <button>{isLiked ? "❤️ " : "🤍"}</button>
    </div>
  );
}
// 컴포넌트 정의
function Discount({ price, discount }) {
  return (
    <div>
      <span style={{ textDecoration: "Line-through" }}>{price}원</span>
      <span>({discount}원)</span>
    </div>
  );
}
function App() {
  return (
    <div>
      <Greeting isLoggedIn={false} />
      <SubscribeButton isSubscribed={true} />
      <StatusBadge isOnline={true} />
      <NewMail newMailCount={4} />
      <OrderStatus status={"pending"} />
      <Weather temperature={0} />
      <ProductCard product={{ name: "노트북", stock: 5, onSale: true }} />
      <Like isLiked={true} />
      <Discount price={1000} discount={800} />
    </div>
  );
}

export default App;
